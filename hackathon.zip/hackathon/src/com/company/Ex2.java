package com.company;
import java.util.Random;
public class Ex2 {
    public static void main(String[] args){
        double a = 20 + Math.random()*40;

        System.out.println(a);
    }
}

